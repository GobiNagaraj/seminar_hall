function Submit_Admin()  
{
	if((txt_Admin_Name ==0) &&(pwd_Admin ==0) && (pwd_Re ==0) && (txt_Admin_Mail ==0))
	 {
	  document.write("Please fill All column");
	 }
	 else
	 (
	  document.write("content Successfully Saved");
	 }
}// JavaScript Document
