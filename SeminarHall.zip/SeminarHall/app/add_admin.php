<?php 

		$servername = "localhost";
		$username = "root";
		$password = "";
		$conn = mysqli_connect($servername, $username, $password,"seminar_hall");
		if (!$conn) 
		{
		    die("Connection failed: " . mysqli_connect_error());
		}

		$name = "Gobi";
		$pass = "gobi@123";
		if(($name == $_POST['admin_Name']) || ($pass == $_POST['admin_Password'])){
			//echo "Successfully Login";
			header('Location: ../Admin_Edit.html');
		}
		else{
			echo "Not Login";
		}
		/*if($_POST['admin_Name'] && $_POST['admin_Password']) {  
             
             if("$username = admin_name"){  
      		 $isadmin = mysql_query("SELECT admin_name FROM admin_entry WHERE admin_name = 'username'");  
        	 while ($row = mysql_fetch_assoc($isadmin)){

         	 $dbusername = $row['admin_name'];  
             //$dbpassword = $row ['admin_pass'];  

             print_r(isadmin);
}   
}
}
			if("$userpass = admin_pass"){  
      		 $isadmin = mysql_query("SELECT admin_pass FROM admin_entry WHERE admin_pass = 'userpass'");  
        	 while ($row = mysql_fetch_assoc($isadmin)){

         	 //$dbusername = $row['admin_name'];  
             $dbpassword = $row ['admin_pass'];  

             print_r(isadmin);
}   
}

        if ($userpass == $dbusername && $password == $dbpassword){  
	        echo "You are in Admin page";          

      }   
      else {
       echo"Incorrect password";  
    }  
  */


		