
<?php 



	    $servername = "localhost";
		$username = "root";
		$password = "";

		$conn = mysqli_connect($servername, $username, $password,"seminar_hall");
		if (!$conn) {
		    die("Connection failed: " . mysqli_connect_error());
		}
		$sql = "INSERT INTO `user`(`name`, `password`, `re_pass`, `mail`) VALUES ('".$_POST['admin_Name']."','".$_POST['admin_Pass']."','".$_POST['admin_repass']."','".$_POST['admin_mail']."')";
		print_r($sql);
		 if($conn->query($sql)){
		 	echo "data inserted";
		 }
		 else{
			echo "not inserted";
		}

		/*$sql = "SELECT * FROM `user` WHERE `name`='".$_POST["admin_Pass"]."'";
		print_r($sql);*/

		//$sel = "SELECT 'name', `password`, `re_pass`, `mail` FROM `user` ";

		/*$check = "SELECT name,password FROM user";
		$result = mysqli_query($conn,$sql);
		//$result = $conn->query($sql);

		//if ($result->num_rows > 0) {
			//output data of each row

		if (mysqli_num_rows($result)>0)  {
			while ($row = mysqli_fetch_assoc($result)) {	
				echo "name:".$row[admin_Name]."- Password:".$row[admin_Pass]."".$row[admin_repass]."<br>";
			}
		}
			else{
				echo "0 result";
			}*/
		//print_r($sel);
	