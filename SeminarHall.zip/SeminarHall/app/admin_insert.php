<?php 

		$servername = "localhost";
		$username = "root";
		$password = "";
		$conn = mysqli_connect($servername, $username, $password,"seminar_hall");
		if (!$conn) 
		{
		    die("Connection failed: " . mysqli_connect_error());
		}

		$sql = "SELECT * FROM `user` WHERE `admin_Name`='".$_POST["admin_Pass"]."'";
		$result = $conn->query($sql);
		print_r($sql);
		/*while ($row = $result->fetch_assoc()) {
			$final1[] = $row;
		}
*/
